
class Player:
    def __init__(self):
        self.snippets = 0
        self.has_weapon = False
        self.is_paralyzed = False
        self.row = 0
        self.col = 0
