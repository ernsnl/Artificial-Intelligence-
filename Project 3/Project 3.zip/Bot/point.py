class Point:
    def __init__(self, row, col):
        self.row = row
        self.col = col
